# TEMPLATE CHANGELOG (ALTERAR)

# {version}
[{date}]

### Quebras de compatibilidade
* N/A.

### Novas funcionalidades
* [TASK-XXXX](link-task-jira) - Repositório criado pelo Bot Bastion do Devops

### Melhorias
* [#TASK-XXXX] - AS task também podem ser referenciadas com o # (hash) por conta da integração jira/gitlab

### Correções
* N/A.

### Alterações na base de dados
* N/A.

### Alteração de dependências
* N/A.
