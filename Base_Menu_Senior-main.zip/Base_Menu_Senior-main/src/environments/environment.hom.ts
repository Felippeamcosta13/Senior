export const environment = {
  server: 'https://189.16.40.163:8181',
  client_id: ''
}
