export const environment = {
  server: 'https://189.16.40.163:8181',
  client_id: '',
  fluxo: 'composable',
  valida_versao: false,
  versao: '1.0.0',
  ambiente: 'E'
}
