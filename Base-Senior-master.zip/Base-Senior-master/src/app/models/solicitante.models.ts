export interface SolicitanteModel {
//   retornoTipAco: string;
//   retornoCodPla: number;
//   retornoNomPla: string;
//   retornoNumCad: number;
//   retornoTipCol: number;
//   retornoNumEmp: number;
//   retornoNomeCompleto: string;
//   retornoErro: string;
//   retornoEmail: string;
//   retornoNomEmp: string;
//   retornoNomFil: string;
//   retornoCodFil: number;
//   retornoCodCcu: string;
//   retornoNomCcu: string;
//   isGestor: number;
//   erroExecucao: string;
}