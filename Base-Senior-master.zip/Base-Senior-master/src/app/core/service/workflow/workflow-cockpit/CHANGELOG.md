# 2.0.4
[22/03/2019]
* Corrigido mapeamento para arquivos de definição TypeScript (.d.ts).

# 2.0.3
[22/03/2019]
* Corrigido build da versão standalone.

# 2.0.2
[22/03/2019]
* Adicionada configuração para build do módulo e versão standalone.

# 2.0.1
[21/03/2019]
* Versão privada;
* Alteradas configurações do projeto para exportar a função workflowCockpit;
* Criado arquivo de definição TypeScript (.d.ts) pra o pacote.

# 2.0.0
[20/03/2019]
* Versão privada;
* Alterado para versão 2.x, a partir desta versão o projeto será publicado como um módulo.

# 1.8.0
[20/06/2018]

* [TECWKF-1075](http://jira.senior.com.br/browse/TECWKF-1075) - Adicionando novas informações para o customizador de formulários do Workflow, como o nome da tarefa, próxima ação a ser executada e qual o próximo usuário escolhido na tarefa.
* [TECWKF-1082](http://jira.senior.com.br/browse/TECWKF-1082) - Disponibilizar dados do processo na API do workflow.
