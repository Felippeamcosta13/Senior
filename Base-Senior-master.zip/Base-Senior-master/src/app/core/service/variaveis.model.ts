/* eslint-disable @typescript-eslint/no-empty-object-type */

export interface VariaveisProcessoModel {
 dadosVeiculo:any

}
